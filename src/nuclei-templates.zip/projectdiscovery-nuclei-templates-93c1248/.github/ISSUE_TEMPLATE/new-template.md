---
name: Template Request
about: 'request for new template to be created.'
labels: 'new-template'

---

<!-- ISSUES MISSING IMPORTANT INFORMATION MAY BE CLOSED WITHOUT INVESTIGATION. -->


### Template for?

<!-- Name the CVE / Vulnerability / Exploit / Misconfiguration / Technology -->

### Details:

<!-- Required information to create a nuclei template such as exploit link / source / reference / vulnerable setup / search query / demo host -->