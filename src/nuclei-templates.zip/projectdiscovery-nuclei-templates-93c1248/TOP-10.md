|    TAG    | COUNT |    AUTHOR    | COUNT |     DIRECTORY     | COUNT | SEVERITY | COUNT | TYPE | COUNT |
|-----------|-------|--------------|-------|-------------------|-------|----------|-------|------|-------|
| cve       |  2271 | dhiyaneshdk  |  1109 | http              |  6856 | info     |  3326 | file |   312 |
| panel     |  1034 | dwisiswant0  |   800 | file              |   312 | high     |  1439 | dns  |    18 |
| wordpress |   929 | daffainfo    |   787 | workflows         |   191 | medium   |  1429 |      |       |
| xss       |   845 | pikpikcu     |   353 | network           |   133 | critical |   906 |      |       |
| exposure  |   833 | pussycat0x   |   307 | ssl               |    27 | low      |   245 |      |       |
| wp-plugin |   811 | ritikchaddha |   293 | javascript        |    20 | unknown  |    32 |      |       |
| osint     |   675 | pdteam       |   283 | dns               |    17 |          |       |      |       |
| tech      |   645 | ricardomaia  |   229 | headless          |    10 |          |       |      |       |
| lfi       |   614 | geeknik      |   221 | code              |     2 |          |       |      |       |
| edb       |   598 | theamanrawat |   221 | contributors.json |     1 |          |       |      |       |
